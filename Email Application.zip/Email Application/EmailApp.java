
/**
 * Write a description of class EmailApp here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EmailApp{
    public static void main(String[] args) {
        Email em1 = new Email("Ethan", "Trammell");
        System.out.println(em1.showInfo());
        
    }
}
